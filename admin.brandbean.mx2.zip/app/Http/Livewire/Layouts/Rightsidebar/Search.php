<?php

namespace App\Http\Livewire\Layouts\Rightsidebar;

use Livewire\Component;

class Search extends Component
{
    public function render()
    {
        return view('livewire.layouts.rightsidebar.search');
    }
}
