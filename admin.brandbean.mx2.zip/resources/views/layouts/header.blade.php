<div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="d-flex flex-row flex-column-fluid page">
       
        @include('layouts.left-sidebar')

        @include('layouts.right-sidebar')

    </div>
    <!--end::Page-->
</div>
<!--end::Main-->



